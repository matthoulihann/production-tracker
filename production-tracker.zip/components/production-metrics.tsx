"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

// Mock data for the chart
const initialData = [
  { day: "Mon", line1: 420, line2: 380, line3: 290, line4: 340 },
  { day: "Tue", line1: 450, line2: 400, line3: 310, line4: 360 },
  { day: "Wed", line1: 430, line2: 410, line3: 320, line4: 350 },
  { day: "Thu", line1: 460, line2: 390, line3: 300, line4: 370 },
  { day: "Fri", line1: 480, line2: 420, line3: 330, line4: 390 },
  { day: "Sat", line1: 400, line2: 370, line3: 280, line4: 330 },
  { day: "Sun", line1: 380, line2: 350, line3: 270, line4: 320 },
]

export default function ProductionMetrics() {
  const [data, setData] = useState<typeof initialData>([])

  // Simulate data loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setData(initialData)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="h-[300px] w-full">
      {data.length === 0 ? (
        <div className="flex h-full items-center justify-center">
          <p className="text-sm text-muted-foreground">Loading production data...</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="day" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="line1" name="Line 1 - Assembly" fill="#2563eb" />
            <Bar dataKey="line2" name="Line 2 - Packaging" fill="#0891b2" />
            <Bar dataKey="line3" name="Line 3 - Quality Control" fill="#4f46e5" />
            <Bar dataKey="line4" name="Line 4 - Finishing" fill="#7c3aed" />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}
