"use client"

import { useState, useEffect } from "react"
import { ArrowUpDown, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { getRecentSubmissions } from "@/lib/actions"
import type { Submission } from "@/lib/actions"

export default function RecentSubmissions() {
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [loading, setLoading] = useState(true)
  const [sortField, setSortField] = useState<keyof Submission>("timestamp")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  useEffect(() => {
    async function loadData() {
      try {
        const data = await getRecentSubmissions()
        setSubmissions(data)
      } catch (error) {
        console.error("Failed to load submissions:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const handleSort = (field: keyof Submission) => {
    if (field === sortField) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const sortedSubmissions = [...submissions].sort((a, b) => {
    if (sortField === "unitsCompleted") {
      return sortDirection === "asc" ? a.unitsCompleted - b.unitsCompleted : b.unitsCompleted - a.unitsCompleted
    } else {
      const aValue = a[sortField]
      const bValue = b[sortField]
      if (sortDirection === "asc") {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0
      }
    }
  })

  if (loading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <p className="text-sm text-muted-foreground">Loading recent submissions...</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <div className="relative w-full overflow-auto">
          <table className="w-full caption-bottom text-sm">
            <thead className="[&_tr]:border-b">
              <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                <th className="h-10 px-2 text-left font-medium">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1 -ml-3 h-8"
                    onClick={() => handleSort("employeeId")}
                  >
                    Employee
                    <ArrowUpDown className="h-3 w-3" />
                  </Button>
                </th>
                <th className="h-10 px-2 text-left font-medium">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1 -ml-3 h-8"
                    onClick={() => handleSort("line")}
                  >
                    Line
                    <ArrowUpDown className="h-3 w-3" />
                  </Button>
                </th>
                <th className="h-10 px-2 text-left font-medium">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1 -ml-3 h-8"
                    onClick={() => handleSort("unitsCompleted")}
                  >
                    Units
                    <ArrowUpDown className="h-3 w-3" />
                  </Button>
                </th>
                <th className="h-10 px-2 text-left font-medium">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1 -ml-3 h-8"
                    onClick={() => handleSort("timestamp")}
                  >
                    Time
                    <ArrowUpDown className="h-3 w-3" />
                  </Button>
                </th>
                <th className="h-10 w-[30px]"></th>
              </tr>
            </thead>
            <tbody className="[&_tr:last-child]:border-0">
              {sortedSubmissions.map((submission) => (
                <tr
                  key={submission.id}
                  className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                >
                  <td className="p-2 align-middle font-medium">{submission.employeeId}</td>
                  <td className="p-2 align-middle">
                    {submission.line === "line1" && "Line 1"}
                    {submission.line === "line2" && "Line 2"}
                    {submission.line === "line3" && "Line 3"}
                    {submission.line === "line4" && "Line 4"}
                  </td>
                  <td className="p-2 align-middle">{submission.unitsCompleted}</td>
                  <td className="p-2 align-middle text-muted-foreground">
                    {new Date(submission.timestamp).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </td>
                  <td className="p-2 align-middle">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>View details</DropdownMenuItem>
                        <DropdownMenuItem>Edit submission</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
