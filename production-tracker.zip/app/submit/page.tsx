"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Factory, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { submitProductionData } from "@/lib/actions"
import { toast } from "@/components/ui/use-toast"

const formSchema = z.object({
  employeeId: z.string().min(3, {
    message: "Employee ID must be at least 3 characters.",
  }),
  shift: z.string({
    required_error: "Please select a shift.",
  }),
  line: z.string({
    required_error: "Please select a production line.",
  }),
  unitsCompleted: z.coerce
    .number()
    .min(1, {
      message: "Units completed must be at least 1.",
    })
    .max(1000, {
      message: "Units completed cannot exceed 1000.",
    }),
  comments: z.string().optional(),
})

export default function SubmitPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      employeeId: "",
      shift: "",
      line: "",
      unitsCompleted: undefined,
      comments: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)
    try {
      // In a real app, this would call an API endpoint
      await submitProductionData(values)
      toast({
        title: "Submission successful",
        description: `Recorded ${values.unitsCompleted} units for employee ${values.employeeId}`,
      })
      router.push("/")
    } catch (error) {
      toast({
        title: "Submission failed",
        description: "There was an error submitting your production data.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Factory className="h-6 w-6" />
            <h1 className="text-xl font-bold">Production Line Tracker</h1>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/submit" className="text-sm font-medium">
              Submit Data
            </Link>
            <Button size="sm" variant="outline">
              Sign Out
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="mx-auto max-w-2xl">
          <Button variant="ghost" size="sm" className="mb-4" asChild>
            <Link href="/" className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>Submit Production Data</CardTitle>
              <CardDescription>Enter the details of your production shift</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="employeeId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Employee ID</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your ID" {...field} />
                          </FormControl>
                          <FormDescription>Your employee identification number</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="shift"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Shift</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select shift" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="morning">Morning (6AM-2PM)</SelectItem>
                              <SelectItem value="afternoon">Afternoon (2PM-10PM)</SelectItem>
                              <SelectItem value="night">Night (10PM-6AM)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>The shift you worked</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="line"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Production Line</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select line" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="line1">Line 1 - Assembly</SelectItem>
                              <SelectItem value="line2">Line 2 - Packaging</SelectItem>
                              <SelectItem value="line3">Line 3 - Quality Control</SelectItem>
                              <SelectItem value="line4">Line 4 - Finishing</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>The production line you worked on</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="unitsCompleted"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Units Completed</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="0" {...field} />
                          </FormControl>
                          <FormDescription>Number of units processed during your shift</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="comments"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Comments (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="Any issues or notes about your shift" {...field} />
                        </FormControl>
                        <FormDescription>Add any relevant information about your production shift</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <CardFooter className="px-0 pt-4">
                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? "Submitting..." : "Submit Production Data"}
                    </Button>
                  </CardFooter>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>
      <footer className="border-t py-4">
        <div className="container flex flex-col gap-2 text-center text-xs text-muted-foreground md:flex-row md:justify-between">
          <p>© 2025 Production Line Tracker. All rights reserved.</p>
          <p>Created for ABB demonstration</p>
        </div>
      </footer>
    </div>
  )
}
