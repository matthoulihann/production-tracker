// This script initializes the SQLite database with schema and sample data
const Database = require("better-sqlite3")
const path = require("path")
const fs = require("fs")

// Create database file path
const dbPath = path.join(process.cwd(), "production-tracker.db")

// Remove existing database if it exists
if (fs.existsSync(dbPath)) {
  console.log("Removing existing database...")
  fs.unlinkSync(dbPath)
}

// Create a new database connection
const db = new Database(dbPath)
console.log("Database created at:", dbPath)

// Enable foreign keys
db.pragma("foreign_keys = ON")

// Create tables
console.log("Creating tables...")
db.exec(`
  CREATE TABLE production_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL,
    shift TEXT NOT NULL,
    line TEXT NOT NULL,
    units_completed INTEGER NOT NULL,
    comments TEXT,
    timestamp TEXT NOT NULL
  );
`)

// Insert sample data
console.log("Inserting sample data...")
const insert = db.prepare(`
  INSERT INTO production_data (employee_id, shift, line, units_completed, comments, timestamp)
  VALUES (?, ?, ?, ?, ?, ?)
`)

// Generate dates for the past week
const now = new Date()
const dates = []
for (let i = 0; i < 7; i++) {
  const date = new Date(now)
  date.setDate(date.getDate() - i)
  dates.push(date)
}

// Sample data for each production line over the past week
const lines = ["line1", "line2", "line3", "line4"]
const shifts = ["morning", "afternoon", "night"]
const employees = ["EMP001", "EMP002", "EMP003", "EMP004", "EMP005", "EMP006"]
const comments = [
  "",
  "Machine maintenance required",
  "New material batch started",
  "Quality check passed",
  "Minor delay due to supply issue",
]

// Generate realistic production data
let count = 0
dates.forEach((date) => {
  lines.forEach((line) => {
    shifts.forEach((shift) => {
      // Add 1-3 entries per shift per line per day
      const entriesCount = Math.floor(Math.random() * 3) + 1

      for (let i = 0; i < entriesCount; i++) {
        const employeeId = employees[Math.floor(Math.random() * employees.length)]
        const unitsCompleted = Math.floor(Math.random() * 200) + 250 // Between 250-450 units
        const comment = comments[Math.floor(Math.random() * comments.length)]

        // Adjust timestamp based on shift
        const timestamp = new Date(date)
        if (shift === "morning") {
          timestamp.setHours(8 + Math.floor(Math.random() * 6)) // 8AM-2PM
        } else if (shift === "afternoon") {
          timestamp.setHours(14 + Math.floor(Math.random() * 6)) // 2PM-8PM
        } else {
          timestamp.setHours(22 + Math.floor(Math.random() * 6)) // 10PM-4AM
          if (timestamp.getHours() < 6) {
            // If hours rolled over to next day, adjust the date
            timestamp.setDate(timestamp.getDate() + 1)
          }
        }

        insert.run(employeeId, shift, line, unitsCompleted, comment, timestamp.toISOString())

        count++
      }
    })
  })
})

console.log(`Inserted ${count} sample records.`)
console.log("Database initialization complete!")

// Close the database connection
db.close()
