import Database from "better-sqlite3"
import path from "path"

// This is a singleton pattern to maintain a single database connection
let db: Database.Database | null = null

export function getDb() {
  if (!db) {
    // Create a database connection
    const dbPath = path.join(process.cwd(), "production-tracker.db")
    db = new Database(dbPath)

    // Enable foreign keys
    db.pragma("foreign_keys = ON")

    // Initialize the database schema if it doesn't exist
    db.exec(`
      CREATE TABLE IF NOT EXISTS production_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id TEXT NOT NULL,
        shift TEXT NOT NULL,
        line TEXT NOT NULL,
        units_completed INTEGER NOT NULL,
        comments TEXT,
        timestamp TEXT NOT NULL
      );
    `)

    // Insert some sample data if the table is empty
    const count = db.prepare("SELECT COUNT(*) as count FROM production_data").get() as { count: number }

    if (count.count === 0) {
      const insert = db.prepare(`
        INSERT INTO production_data (employee_id, shift, line, units_completed, comments, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
      `)

      // Sample data
      const sampleData = [
        {
          employeeId: "EMP001",
          shift: "morning",
          line: "line1",
          unitsCompleted: 432,
          comments: "",
          timestamp: new Date(Date.now() - 3600000).toISOString(),
        },
        {
          employeeId: "EMP002",
          shift: "morning",
          line: "line2",
          unitsCompleted: 387,
          comments: "Machine 3 needed maintenance",
          timestamp: new Date(Date.now() - 7200000).toISOString(),
        },
        {
          employeeId: "EMP003",
          shift: "afternoon",
          line: "line3",
          unitsCompleted: 298,
          comments: "",
          timestamp: new Date(Date.now() - 10800000).toISOString(),
        },
        {
          employeeId: "EMP004",
          shift: "afternoon",
          line: "line4",
          unitsCompleted: 356,
          comments: "New material batch started",
          timestamp: new Date(Date.now() - 14400000).toISOString(),
        },
        {
          employeeId: "EMP005",
          shift: "night",
          line: "line1",
          unitsCompleted: 412,
          comments: "",
          timestamp: new Date(Date.now() - 86400000).toISOString(),
        },
      ]

      // Insert sample data
      for (const data of sampleData) {
        insert.run(data.employeeId, data.shift, data.line, data.unitsCompleted, data.comments, data.timestamp)
      }
    }
  }

  return db
}

// Helper function to close the database connection
export function closeDb() {
  if (db) {
    db.close()
    db = null
  }
}
