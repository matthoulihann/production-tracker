"use server"

import { getDb } from "./db"
import { z } from "zod"

// Define the submission type
export type Submission = {
  id: string
  employeeId: string
  shift: string
  line: string
  unitsCompleted: number
  comments?: string
  timestamp: string
}

// Define the form schema
const formSchema = z.object({
  employeeId: z.string().min(3),
  shift: z.string(),
  line: z.string(),
  unitsCompleted: z.coerce.number().min(1).max(1000),
  comments: z.string().optional(),
})

export async function getRecentSubmissions(): Promise<Submission[]> {
  const db = getDb()

  // Query the database for recent submissions
  const submissions = db
    .prepare(`
    SELECT 
      id, 
      employee_id as employeeId, 
      shift, 
      line, 
      units_completed as unitsCompleted, 
      comments, 
      timestamp 
    FROM production_data 
    ORDER BY timestamp DESC 
    LIMIT 10
  `)
    .all() as Submission[]

  return submissions
}

export async function submitProductionData(data: z.infer<typeof formSchema>) {
  const db = getDb()

  // Prepare the statement
  const stmt = db.prepare(`
    INSERT INTO production_data (
      employee_id, 
      shift, 
      line, 
      units_completed, 
      comments, 
      timestamp
    ) VALUES (?, ?, ?, ?, ?, ?)
  `)

  // Execute the statement
  const info = stmt.run(
    data.employeeId,
    data.shift,
    data.line,
    data.unitsCompleted,
    data.comments || "",
    new Date().toISOString(),
  )

  // Return the newly created submission
  return {
    id: info.lastInsertRowid.toString(),
    ...data,
    timestamp: new Date().toISOString(),
  }
}

export async function getProductionMetrics() {
  const db = getDb()

  // Get today's date in ISO format (YYYY-MM-DD)
  const today = new Date().toISOString().split("T")[0]

  // Query for total units today
  const totalToday = db
    .prepare(`
    SELECT SUM(units_completed) as total 
    FROM production_data 
    WHERE timestamp LIKE ?
  `)
    .get(`${today}%`) as { total: number } | undefined

  // Query for average per shift
  const averagePerShift = db
    .prepare(`
    SELECT AVG(units_completed) as average 
    FROM production_data
  `)
    .get() as { average: number } | undefined

  // Count distinct employees
  const activeEmployees = db
    .prepare(`
    SELECT COUNT(DISTINCT employee_id) as count 
    FROM production_data 
    WHERE timestamp >= datetime('now', '-24 hours')
  `)
    .get() as { count: number } | undefined

  // In a real application, you would calculate efficiency based on targets
  // For demo purposes, we'll return a fixed value or calculate a simple metric
  return {
    totalToday: totalToday?.total || 0,
    averagePerShift: Math.round(averagePerShift?.average || 0),
    efficiencyRate: 92.4, // This would be calculated in a real app
    activeEmployees: activeEmployees?.count || 0,
  }
}
